"""CalverIS Core."""
__version__ = "0.2.0-alpha.2"
